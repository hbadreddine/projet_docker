#!/bin/sh


docker pull kartoza/geoserver
docker run --name geoserver -d -p 8080:8080 kartoza/geoserver