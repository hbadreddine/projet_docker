


CREATE DATABASE spatialdata;
\c spatialdata
CREATE EXTENSION postgis;
CREATE SEQUENCE serial START 1;
