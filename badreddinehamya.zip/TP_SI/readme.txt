configurer le Vagrantfile:
                 # -*- mode: ruby -*-
                 # vi: set ft=ruby :

                VAGRANTFILE_API_VERSION = "2"

                Vagrant.configure(VAGRANTFILE_API_VERSION) do |config|
                config.vm.box = "dduportal/boot2docker"

                # PostgreSQL NAT
                config.vm.network :forwarded_port, guest: 5432, host: 2200, auto_correct: true

  
                # Geoserver
                config.vm.network :forwarded_port, guest: 8080, host: 8080, auto_correct: true
  
               end




lancer la machine virtuelle a partir de la console:
    - lancer env.bat    
	- vagrant plugin install vagrant-proxyconf
	- vagrant up
	- vagrant ssh
	
	
	
lancer commandes_postgresql.sh
    - charge l'image 
	- lancer un container pour le serveur
	- lance un container client et exécute le fichier mabase.sql (création d'une base de donnée, ajout de l'extension postgis 

lancer commandes_geoserver.sh


configurer le port de postgres du windows: dans mon cas 2200


création dune liaison entre les deux containers
docker run --name geoserver -d --link dbserver:ps  -p 8080:8080 kartoza/geoserver


ouvrir postgis a partir du windows: importer le shapefile a partir du dossier sources
     -username: postgres
	 -password: postgres
	 -Server host: 127.0.0.1      2200
	 -Database: spatialdata
	 

lancer geoserver:	 
     - dans un browser taper: localhost:8080/geoserver
     - se connecter: username: admin  mot de passe: geoserver
     - créer un nouveau entrepot :
	         - choisir PostGIS comme source de données
			 - host= adresse du serveur postgres (deja retrouvé avec docker inspect)
			 - port 5432
			 - spatialdata
			 - user: postgres
			 - password: postgres
			 - sauvegarder 
			 - publier apres la configuration
	 - a partir du menu prévisualiser une couche, on peut visualiser les shapefiles.		 

	